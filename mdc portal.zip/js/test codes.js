

 // Get the modal for prosthodontics
 
 var modal = document.getElementById("myModal3");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn3");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for PHD

 var modal = document.getElementById("myModal4");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn4");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for conserve

 var modal = document.getElementById("myModal5");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn5");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for ortho

 var modal = document.getElementById("myModal6");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn6");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for pedodontics

 var modal = document.getElementById("myModal7");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn7");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for periodontics

 var modal = document.getElementById("myModal8");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn8");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Basic science

 var modal = document.getElementById("myModal9");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn9");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Hostel

 var modal = document.getElementById("myModal10");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn10");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Administration

 var modal = document.getElementById("myModal11");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn11");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Princiapal

 var modal = document.getElementById("myModal12");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn12");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Library

 var modal = document.getElementById("myModal13");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn13");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for Projects

 var modal = document.getElementById("myModal14");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn14");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }

 // Get the modal for store

 var modal = document.getElementById("myModal15");

 // Get the button that opens the modal
 var btn = document.getElementById("myBtn15");
 
 // Get the <span> element that closes the modal
 var span = document.getElementsByClassName("close");
 
 // When the user clicks the button, open the modal 
 btn.onclick = function() {
   modal.style.display = "block";
 }
 
 // When the user clicks on <span> (x), close the modal
 span.onclick = function() {
   modal.style.display = "none";
 }
 
 // When the user clicks anywhere outside of the modal, close it
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }
